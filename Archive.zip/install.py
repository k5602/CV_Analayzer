import os
import sys
import subprocess
import argparse
import platform
import tempfile
import shutil
from pathlib import Path


def check_python_version():
    """Check if Python version is compatible."""
    if sys.version_info < (3, 7):
        print("Error: Python 3.7 or newer is required.")
        print(f"You are using Python {platform.python_version()}")
        sys.exit(1)
    else:
        print(f"Python version {platform.python_version()} - OK")

def check_tesseract_installation():
    """Check if Tesseract OCR is installed."""
    try:
        # Check if tesseract is in PATH
        tesseract_version = subprocess.run(
            ["tesseract", "--version"], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True, 
            timeout=5
        )
        if tesseract_version.returncode == 0:
            print("Tesseract OCR detected - OK")
            return True
        return False
    except (subprocess.SubprocessError, FileNotFoundError):
        return False


def create_virtual_env(venv_path, upgrade_pip=True, verbose=False):
    """Create a virtual environment at the specified path."""
    venv_path = Path(venv_path)
    if venv_path.exists():
        print(f"Virtual environment already exists at: {venv_path}")
        return venv_path

    print(f"Creating virtual environment at: {venv_path}")
    
    try:
        subprocess.run([sys.executable, "-m", "venv", str(venv_path)], check=True, 
                      capture_output=not verbose)
        
        # Determine pip path for the virtual environment
        if platform.system() == "Windows":
            pip_path = venv_path / "Scripts" / "pip"
        else:
            pip_path = venv_path / "bin" / "pip"
        
        # Upgrade pip if requested
        if upgrade_pip:
            print("Upgrading pip in the virtual environment...")
            subprocess.run([str(pip_path), "install", "--upgrade", "pip"],
                         check=True, capture_output=not verbose)
        
        return venv_path
    
    except subprocess.CalledProcessError as e:
        print(f"Error creating virtual environment: {e}")
        if verbose and e.stderr:
            print(f"Error details: {e.stderr.decode('utf-8')}")
        sys.exit(1)


def install_requirements(venv_path, upgrade=False, minimal=False, verbose=False):
    """Install project requirements in the virtual environment."""
    # Determine path to requirements file
    base_dir = Path(__file__).parent
    req_file = base_dir / "requirements.txt"
    
    if not req_file.exists():
        print(f"Error: Requirements file not found at {req_file}")
        sys.exit(1)
    
    # Determine pip executable for the virtual environment
    if platform.system() == "Windows":
        pip_path = venv_path / "Scripts" / "pip"
    else:
        pip_path = venv_path / "bin" / "pip"
    
    print("Installing dependencies...")
    
    # Prepare install command
    cmd = [str(pip_path), "install"]
    if upgrade:
        cmd.append("--upgrade")
    
    # Special handling for minimal installation (avoid problematic packages)
    if minimal:
        # Read requirements file but skip certain packages
        with open(req_file, "r") as f:
            requirements = []
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                    
                # Skip problematic packages
                skip_packages = ["spacy", "sentence-transformers", "keybert"]
                if any(package in line for package in skip_packages):
                    print(f"Skipping problematic package: {line}")
                    continue
                    
                requirements.append(line)
        
        # Write temporary requirements file
        with tempfile.NamedTemporaryFile(mode="w", delete=False) as tmp_file:
            for req in requirements:
                tmp_file.write(f"{req}\n")
            tmp_req_file = tmp_file.name
        
        cmd.extend(["-r", tmp_req_file])
    else:
        cmd.extend(["-r", str(req_file)])
    
    try:
        print("Running: " + " ".join(cmd))
        subprocess.run(cmd, check=True, capture_output=not verbose)
        
        # Install spaCy model if spaCy was installed
        if not minimal:
            try:
                spacy_command = [
                    str(venv_path / ("Scripts" if platform.system() == "Windows" else "bin") / "python"),
                    "-m", "spacy", "download", "en_core_web_sm"
                ]
                print("Installing spaCy language model...")
                subprocess.run(spacy_command, check=True, capture_output=not verbose)
            except subprocess.CalledProcessError as e:
                print(f"Warning: Could not install spaCy language model: {e}")
                if verbose and e.stderr:
                    print(f"Error details: {e.stderr.decode('utf-8')}")
    
    except subprocess.CalledProcessError as e:
        print(f"Error installing requirements: {e}")
        if verbose and e.stderr:
            print(f"Error details: {e.stderr.decode('utf-8')}")
        if not minimal:
            print("\nInstallation failed with full dependencies.")
            print("Attempting installation with minimal dependencies...")
            install_requirements(venv_path, upgrade, minimal=True, verbose=verbose)
        else:
            sys.exit(1)
    
    finally:
        # Clean up temporary file if used
        if minimal:
            try:
                os.unlink(tmp_req_file)
            except:
                pass


def print_success_message(venv_path):
    """Print success message with instructions."""
    activate_path = venv_path / ("Scripts" if platform.system() == "Windows" else "bin") / "activate"
    
    print("\n" + "=" * 50)
    print("Installation completed successfully!")
    print("=" * 50)
    
    print("\nTo activate the virtual environment:")
    if platform.system() == "Windows":
        print(f"    {activate_path}")
    else:
        print(f"    source {activate_path}")
    
    print("\nTo run the application:")
    if platform.system() == "Windows":
        print(f"    {venv_path}\\Scripts\\python main.py")
    else:
        print(f"    {venv_path}/bin/python main.py")
    
    # Check for Tesseract again
    if not check_tesseract_installation():
        print("\nIMPORTANT: For OCR functionality to work with image-based PDFs,")
        print("please install Tesseract OCR and ensure it's in your PATH.")
    
    print("\nNote: If you encounter any issues with dependencies, try running:")
    print(f"    python {__file__} --minimal")
    print("This will install a minimal set of dependencies for basic functionality.")
    print("=" * 50)


def main():
    """Main function to handle the installation process."""
    parser = argparse.ArgumentParser(description="Install CV Analyzer and its dependencies")
    parser.add_argument("--venv", default="venv", help="Path for the virtual environment")
    parser.add_argument("--upgrade", action="store_true", help="Upgrade existing packages")
    parser.add_argument("--minimal", action="store_true", help="Install minimal dependencies only")
    parser.add_argument("--verbose", action="store_true", help="Show verbose output")
    
    args = parser.parse_args()
    
    print("CV Analyzer - Installation Script")
    print("=================================")
    
    # Check Python version
    check_python_version()
    
    # Check for Tesseract OCR
    tesseract_available = check_tesseract_installation()
    if not tesseract_available:
        print("\nWARNING: Tesseract OCR not detected!")
        print("OCR functionality for processing image-based PDFs will be limited.")
        print("To enable full OCR functionality, please install Tesseract:")
        if platform.system() == "Windows":
            print("  - Download from: https://github.com/UB-Mannheim/tesseract/wiki")
        elif platform.system() == "Darwin":  # macOS
            print("  - Install via Homebrew: brew install tesseract")
        else:  # Linux
            print("  - Install via apt: sudo apt-get install tesseract-ocr")
        print("  - Ensure tesseract is added to your system PATH")
        
        proceed = input("\nDo you want to continue with installation anyway? (y/n): ")
        if proceed.lower() != 'y':
            print("Installation aborted. Please install Tesseract OCR and try again.")
            sys.exit(0)
    
    # Create or use existing virtual environment
    venv_path = create_virtual_env(args.venv, verbose=args.verbose)
    
    # Install dependencies
    install_requirements(venv_path, args.upgrade, args.minimal, args.verbose)
    
    # Print success message
    print_success_message(venv_path)


if __name__ == "__main__":
    main()